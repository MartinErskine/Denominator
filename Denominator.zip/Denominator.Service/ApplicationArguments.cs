﻿namespace Denominator.Service
{
    public class ApplicationArguments
    {
        public string Cost { get; set; }
        public string Tendered { get; set; }
    }
}
